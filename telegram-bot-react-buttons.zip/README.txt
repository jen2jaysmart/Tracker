# Telegram Solana Tracker Bot (Vercel + Telegram)

## Features:
- Telegram button interface (no commands)
- Add wallets to track via buttons
- Toggle which transaction types you want
- External Solana webhook alerts (e.g. from Helius)
- Auth header protection on webhook POST

## Set Up:
1. Deploy to Vercel
2. Set Telegram webhook:
   https://api.telegram.org/bot<your_bot_token>/setWebhook?url=https://your-vercel.vercel.app/api/huium-webhook
3. Use AUTH_HEADER = "Bearer mysecretkey" for external POSTs

## Manual Test:
curl -X POST https://your-vercel.vercel.app/api/huium-webhook \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer mysecretkey" \
  -d '{"type":"TRANSFER","source":"Src","destination":"Dest","amount":1,"signature":"abc123"}'