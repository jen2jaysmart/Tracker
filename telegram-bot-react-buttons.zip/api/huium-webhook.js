const axios = require('axios');

// In-memory user state (replace with DB for production)
const users = {};

const TELEGRAM_BOT_TOKEN = '8036078687:AAEpjZ1W1eFV_szpwT00DIIW_6c_3sw_Hqo';
const TELEGRAM_API = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

// Acceptable auth key for external API (like Helius)
const AUTH_HEADER = "Bearer mysecretkey";

// Helper to send message with optional inline buttons
async function sendMessage(chatId, text, buttons = null) {
  const payload = {
    chat_id: chatId,
    text,
    ...(buttons && {
      reply_markup: {
        inline_keyboard: buttons
      }
    })
  };

  return axios.post(`${TELEGRAM_API}/sendMessage`, payload);
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Only POST allowed');

  const auth = req.headers.authorization;
  const data = req.body;

  // If message is from Telegram user
  if (data.message) {
    const chatId = data.message.chat.id;
    const userId = String(chatId);
    const text = data.message.text;

    // Initialize user
    if (!users[userId]) users[userId] = { wallets: [], types: ["TRANSFER"] };

    if (text === "/start") {
      await sendMessage(chatId, "👋 Welcome to the Solana Tracker Bot! Use the buttons below:", [
        [{ text: "➕ Add Wallet", callback_data: "addwallet" }],
        [{ text: "🔔 Toggle TRANSFER", callback_data: "toggle_TRANSFER" }],
        [{ text: "📜 My Wallets", callback_data: "mywallets" }]
      ]);
      return res.status(200).send("Start handled");
    }
  }

  // Handle button presses
  if (data.callback_query) {
    const callback = data.callback_query;
    const chatId = callback.message.chat.id;
    const userId = String(chatId);
    const action = callback.data;

    if (!users[userId]) users[userId] = { wallets: [], types: ["TRANSFER"] };

    if (action === "addwallet") {
      await sendMessage(chatId, "📥 Please send your wallet address (just paste it here).");
      users[userId].awaitingWallet = true;
    } else if (action.startsWith("toggle_")) {
      const type = action.replace("toggle_", "");
      const index = users[userId].types.indexOf(type);
      if (index >= 0) {
        users[userId].types.splice(index, 1);
        await sendMessage(chatId, `❌ Disabled ${type}`);
      } else {
        users[userId].types.push(type);
        await sendMessage(chatId, `✅ Enabled ${type}`);
      }
    } else if (action === "mywallets") {
      const w = users[userId].wallets;
      await sendMessage(chatId, w.length ? "📜 Your Wallets:\n" + w.join("\n") : "❌ No wallets added.");
    }

    return res.status(200).send("Button action handled");
  }

  // Handle follow-up message with wallet (after "awaitingWallet" state)
  if (data.message) {
    const chatId = data.message.chat.id;
    const userId = String(chatId);
    const msg = data.message.text;

    if (users[userId]?.awaitingWallet) {
      users[userId].wallets.push(msg);
      users[userId].awaitingWallet = false;
      await sendMessage(chatId, `✅ Wallet ${msg} added!`);
      return res.status(200).send("Wallet added");
    }
  }

  // Handle external webhook (Helius or others) with auth header
  if (auth === AUTH_HEADER && data.type && data.destination) {
    for (const userId in users) {
      const u = users[userId];
      if (u.wallets.includes(data.destination) && u.types.includes(data.type)) {
        const msg = `🚨 ${data.type} detected!
From: ${data.source}
To: ${data.destination}
Amount: ${data.amount} SOL
Tx: https://solscan.io/tx/${data.signature}`;
        await sendMessage(userId, msg);
      }
    }
    return res.status(200).send("Notification sent");
  }

  res.status(200).send("No action taken");
};