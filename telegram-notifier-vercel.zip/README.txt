Telegram Transaction Notifier for Vercel

1. Unzip the folder.

2. Make sure you have Node.js installed (optional if deploying via Vercel CLI).

3. If you want to deploy via Vercel CLI:

   - Install Vercel CLI: npm install -g vercel
   - Login: vercel login
   - Navigate into this folder and run: vercel
   - Follow the prompts and deploy.

4. Your webhook URL will be:
   https://your-project-name.vercel.app/api/huium-webhook

5. Add this URL to your Huium webhook configuration.

6. To test locally, you can run serverless function simulators or deploy and test using curl:

   curl -X POST https://your-project-name.vercel.app/api/huium-webhook \
   -H "Content-Type: application/json" \
   -d '{"id":"test123", "amount":"100", "status":"completed"}'

7. Customize 'api/huium-webhook.js' to format messages as you prefer.

---

Keep your TELEGRAM_BOT_TOKEN and CHAT_ID private.
