const axios = require('axios');

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).send('Method Not Allowed');
  }

  const transaction = req.body;

  const TELEGRAM_BOT_TOKEN = '8036078687:AAEpjZ1W1eFV_szpwT00DIIW_6c_3sw_Hqo';
  const CHAT_ID = '6934372060';

  const message = `🚨 New Transaction Alert 🚨\n` +
                  `Transaction ID: ${transaction.id || 'N/A'}\n` +
                  `Amount: ${transaction.amount || 'N/A'}\n` +
                  `Status: ${transaction.status || 'N/A'}`;

  try {
    await axios.post(`https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`, {
      chat_id: CHAT_ID,
      text: message,
    });

    res.status(200).send('Notification sent');
  } catch (error) {
    console.error('Telegram sendMessage error:', error.response?.data || error.message);
    res.status(500).send('Failed to send notification');
  }
};
