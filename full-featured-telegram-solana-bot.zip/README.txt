# Telegram Solana Bot + Helius Webhook (Serverless on Vercel)

## Features:
- Users interact via Telegram Bot commands:
  - /start – Welcome message
  - /addwallet <wallet> – Track Solana address
  - /mywallets – List wallets user is tracking
  - /toggle <type> – Enable/disable transaction type (e.g. TRANSFER, NFT_SALE)
  - /types – Show enabled transaction types

## Deploy
1. Deploy this to Vercel.
2. Set webhook URL in Helius to: https://your-vercel-project.vercel.app/api/huium-webhook
3. Helius will notify you on matching transactions.