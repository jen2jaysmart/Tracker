const axios = require('axios');

// Simulated user database in memory (use DB in production)
const userSettings = {};

const TELEGRAM_BOT_TOKEN = '8036078687:AAEpjZ1W1eFV_szpwT00DIIW_6c_3sw_Hqo';
const TELEGRAM_API = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

// Utility: send a message
async function sendTelegramMessage(chatId, text) {
  return axios.post(`${TELEGRAM_API}/sendMessage`, {
    chat_id: chatId,
    text,
  });
}

// Utility: add wallet to user
function addWallet(userId, wallet) {
  if (!userSettings[userId]) userSettings[userId] = { wallets: [], types: ["TRANSFER"] };
  if (!userSettings[userId].wallets.includes(wallet)) {
    userSettings[userId].wallets.push(wallet);
  }
}

// Utility: toggle notification type
function toggleType(userId, type) {
  if (!userSettings[userId]) userSettings[userId] = { wallets: [], types: ["TRANSFER"] };
  const index = userSettings[userId].types.indexOf(type);
  if (index > -1) {
    userSettings[userId].types.splice(index, 1);
    return `❌ Disabled ${type}`;
  } else {
    userSettings[userId].types.push(type);
    return `✅ Enabled ${type}`;
  }
}

module.exports = async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).send('Method Not Allowed');

  const body = req.body;

  // Handle Telegram bot commands
  if (body.message) {
    const msg = body.message;
    const chatId = msg.chat.id;
    const userId = String(chatId);
    const text = msg.text?.trim();

    if (text === "/start") {
      await sendTelegramMessage(chatId, 
        "👋 Welcome to the Solana TX Bot!

" +
        "Use the following commands:
" +
        "/addwallet <wallet_address>
" +
        "/mywallets - view tracked wallets
" +
        "/toggle <type> - enable/disable TX type (e.g. TRANSFER)
" +
        "/types - show your current notification types"
      );
      return res.status(200).send('Start OK');
    }

    if (text?.startsWith("/addwallet")) {
      const wallet = text.split(" ")[1];
      if (!wallet) {
        await sendTelegramMessage(chatId, "❌ Please provide a wallet address.");
      } else {
        addWallet(userId, wallet);
        await sendTelegramMessage(chatId, `✅ Wallet ${wallet} added.`);
      }
      return res.status(200).send('Wallet added');
    }

    if (text?.startsWith("/mywallets")) {
      const wallets = userSettings[userId]?.wallets || [];
      await sendTelegramMessage(chatId, "📬 Your wallets:
" + wallets.join("\n") || "None set.");
      return res.status(200).send('Wallets shown');
    }

    if (text?.startsWith("/toggle")) {
      const type = text.split(" ")[1]?.toUpperCase();
      if (!type) {
        await sendTelegramMessage(chatId, "❌ Please provide a transaction type.");
      } else {
        const result = toggleType(userId, type);
        await sendTelegramMessage(chatId, result);
      }
      return res.status(200).send('Toggled');
    }

    if (text?.startsWith("/types")) {
      const types = userSettings[userId]?.types || [];
      await sendTelegramMessage(chatId, "🔔 Notifications enabled for types:
" + types.join(", "));
      return res.status(200).send('Types listed');
    }

    return res.status(200).send('Command processed');
  }

  // Handle webhook from Helius
  const { type, source, destination, amount, signature } = body;

  for (const userId in userSettings) {
    const settings = userSettings[userId];
    if (
      settings.wallets.includes(destination) &&
      settings.types.includes(type)
    ) {
      const msg = `🚨 ${type} detected!
From: ${source}
To: ${destination}
Amount: ${amount} SOL
Tx: https://solscan.io/tx/${signature}`;
      await sendTelegramMessage(userId, msg);
    }
  }

  res.status(200).send('Processed');
};