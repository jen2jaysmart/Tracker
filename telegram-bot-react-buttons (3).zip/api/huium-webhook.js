const axios = require('axios');

const TELEGRAM_BOT_TOKEN = '8036078687:AAEpjZ1W1eFV_szpwT00DIIW_6c_3sw_Hqo';
const TELEGRAM_API = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;
const AUTH_HEADER = "Bearer mysecretkey";

const users = {};

async function sendMessage(chatId, text, buttons = null) {
  const payload = {
    chat_id: chatId,
    text,
    ...(buttons && {
      reply_markup: {
        inline_keyboard: buttons
      }
    })
  };
  await axios.post(`${TELEGRAM_API}/sendMessage`, payload);
}

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).send('Only POST allowed');

  const auth = req.headers.authorization;
  const data = req.body;

  if (data.message) {
    const chatId = data.message.chat.id;
    const userId = String(chatId);
    const text = data.message.text;

    if (!users[userId]) users[userId] = { wallets: [], types: ["TRANSFER"] };

    if (text === "/start") {
      await sendMessage(chatId, "👋 Welcome to the Solana Tracker Bot! Use the buttons below:", [
        [{ text: "➕ Add Wallet", callback_data: "addwallet" }],
        [{ text: "🔔 Toggle TRANSFER", callback_data: "toggle_TRANSFER" }],
        [{ text: "📜 My Wallets", callback_data: "mywallets" }]
      ]);
      return res.status(200).send("Start handled");
    }

    if (users[userId]?.awaitingWallet) {
      users[userId].wallets.push(text);
      users[userId].awaitingWallet = false;
      await sendMessage(chatId, `✅ Wallet ${text} added!`);
      return res.status(200).send("Wallet added");
    }
  }

  if (data.callback_query) {
    const cb = data.callback_query;
    const chatId = cb.message.chat.id;
    const userId = String(chatId);
    const action = cb.data;

    if (!users[userId]) users[userId] = { wallets: [], types: ["TRANSFER"] };

    if (action === "addwallet") {
      users[userId].awaitingWallet = true;
      await sendMessage(chatId, "📥 Please send your wallet address.");
    } else if (action.startsWith("toggle_")) {
      const type = action.split("_")[1];
      const i = users[userId].types.indexOf(type);
      if (i >= 0) {
        users[userId].types.splice(i, 1);
        await sendMessage(chatId, `❌ Disabled ${type}`);
      } else {
        users[userId].types.push(type);
        await sendMessage(chatId, `✅ Enabled ${type}`);
      }
    } else if (action === "mywallets") {
      const w = users[userId].wallets;
      await sendMessage(chatId, w.length ? `📜 Your Wallets:\n${w.join("\n")}` : "❌ No wallets added.");
    }

    return res.status(200).send("Button handled");
  }

  if (auth === AUTH_HEADER && data.type && data.destination) {
    for (const userId in users) {
      const u = users[userId];
      if (u.wallets.includes(data.destination) && u.types.includes(data.type)) {
        const msg = `🚨 ${data.type} detected!\nFrom: ${data.source}\nTo: ${data.destination}\nAmount: ${data.amount} SOL\nTx: https://solscan.io/tx/${data.signature}`;
        await sendMessage(userId, msg);
      }
    }
    return res.status(200).send("Notification sent");
  }

  res.status(200).send("No action taken");
};